import random

N = 100

edges = []

for i in range(1,N+1):
    for j in range(i+1,N+1):
        if random.random() < 0.5:
            print '%d,%d' % (i,j)
