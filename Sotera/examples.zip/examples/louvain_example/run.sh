cd /home/hadoop/Sotera-distributed-graph-analytics-b3f67d4/dga-giraph/build/dist

./bin/dga-yarn-giraph louvain /project/louvain_example/input/ /project/louvain_example/output/ -w 1 -ca io.edge.reverse.duplicator=true -ca giraph.SplitMasterWorker=false

